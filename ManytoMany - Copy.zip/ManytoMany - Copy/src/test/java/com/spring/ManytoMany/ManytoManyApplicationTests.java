package com.spring.ManytoMany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManytoManyApplicationTests {

	@Test
	void contextLoads() {
	}

}
